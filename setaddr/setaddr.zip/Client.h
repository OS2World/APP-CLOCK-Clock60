#define DID_ADDRESS                 101
#define DID_MODE_6030               103
#define DID_MODE_6036               102
#define DID_NEW_ADDR                104
#define DID_BTN_HELP                107
#define DID_BTN_APPLY               105
#define DID_BTN_CANCEL              106
