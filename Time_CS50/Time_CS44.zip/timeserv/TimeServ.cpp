#define INCL_DOSSEMAPHORES
#define INCL_DOSDATETIME
#include <os2.h>

#include <signal.h>
#include <setjmp.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>

#include "..\dcfioctl.h"
#include "..\sharemem.hpp"
#include "..\dcf77.hpp"
#include "timeserv.hpp"

/*******************************************************************
   Debug-Definitionen; zu TRACE-Zwecken beim Compilieren
      "TRACE" angeben!
 *******************************************************************/
#ifdef TRACE
  void wrtTrace (PCHAR pszTitle, ...);

  #define dprintDT(sz,D,M,Y,h,m,s)      wrtTrace (sz, D, M, 1900+Y, h, m, s)
  #define dprintS(sz)                   wrtTrace (sz)
#else
  #define dprintDT(sz,D,M,Y,h,m,s)
  #define dprintS(sz)
#endif /* TRACE */

#define INTERVAL_ERRWAIT    1


int main (void)
    {
    ULONG           ulInterval, ulErrInterval;
    ULONG           ulcPost;
    BOOL            bSend;
    HEV             hevServer;
    USHORT          usAdapter;
    DCF77SharedMem *pdcf77ShMem;
    DCF77_ALLDATA   SrvrData;

    /* Semaphore anlegen */
    if (DosCreateEventSem ((PSZ)SEMNAME, &hevServer, 0, FALSE))
        {
        fputs (ERROR_SEMAPHORE, stderr);
        return 1;
        }

    /* Kommunikation mit dem Uhr-Treiber aufbauen */
    /*  Die Daten werden �ber das IOCTL-Interface */
    /*  abgeholt und in einem privaten Speicher   */
    /*  abgelegt.                                 */
    dcf77QueryData dcf77Drv;
    if (!dcf77Drv.isOK ())
        {
        fputs (ERROR_DRIVER, stderr);
        return 1;                       // Fehler: Treiber nicht gefunden
        }

    /* Shared memory initialisieren */
    DCF77Communication dcf77Comm;
    dcf77Comm.CreateShMem (PROG_SERVER);
    if (dcf77Comm.getDCFShMemPtr () == NULL)
        {
        fputs (ERROR_ALLOC, stderr);    // Fehler beim allokieren des Shared memory
        return 1;                       //   oder Programm bereits aktiv
        }

    if (dcf77Comm.isClient ())
        {
        fputs (ERROR_CLIENT, stderr);
        return 1;                       // Fehler: LAN::Time-Client bereits aktiv
        }

    ulErrInterval = 0;
    usAdapter     = 0;
    while (TRUE)
        {
        /* Daten holen */
        dcf77Drv.getDCFData ();
        printf ("Das Jahr: %d\n", dcf77Drv.getDCFDataPtr ()->dcf77DateTime.year);
        dprintDT (dcf77Drv.getDCFDataPtr ()->dcf77Status.flStatus & STATUS_TIMEVALID ? TXT_VALID : TXT_INVALID,
            dcf77Drv.getDCFDataPtr ()->dcf77DateTime.day,
            dcf77Drv.getDCFDataPtr ()->dcf77DateTime.month,
            dcf77Drv.getDCFDataPtr ()->dcf77DateTime.year,
            dcf77Drv.getDCFDataPtr ()->dcf77DateTime.hours,
            dcf77Drv.getDCFDataPtr ()->dcf77DateTime.minutes,
            dcf77Drv.getDCFDataPtr ()->dcf77DateTime.seconds);

        /* Intervall holen, falls Uhr aktiv */
        pdcf77ShMem = dcf77Comm.getDCFShMemPtr ();
        ulInterval = pdcf77ShMem->flProgs & PROG_CLOCK ? pdcf77ShMem->dcf77Data.ulInterval : DEFAULT_INTERVAL;
        if (ulInterval < DEFAULT_INTERVAL)
            ulInterval = DEFAULT_INTERVAL;

        if (dcf77Drv.getDCFDataPtr ()->dcf77Status.flStatus & STATUS_TIMEVALID)
            bSend = TRUE;
        else
            {
            /* fehlerhafte Uhrzeit; Falls ulInterval abgelaufen ist => Trotzdem versenden */
            ulErrInterval += INTERVAL_ERRWAIT;

            bSend = (ulErrInterval > ulInterval ) ? TRUE : FALSE;

            ulInterval = INTERVAL_ERRWAIT;
            }

        /* Im Fehlerfall je nach Einstellung Serverzeit senden */
        if (!bSend && pdcf77ShMem->dcf77Data.bSendSrvrTime)
            {
            DATETIME dt;
            PDCF77_DATETIME pdt = &(dcf77Drv.getDCFDataPtr ()->dcf77DateTime);

            DosGetDateTime (&dt);
            pdt->hours    = dt.hours;
            pdt->minutes  = dt.minutes;
            pdt->seconds  = dt.seconds;
            pdt->day      = dt.day;
            pdt->month    = dt.month;
            pdt->year     = dt.year;
            pdt->timezone = TZ_UNK;
            }

        /* Es sind Daten zum Versenden vorhanden */
        SrvrData = *dcf77Drv.getDCFDataPtr ();
        SrvrData.bSize      = sizeof (DCF77_ALLDATA);
        SrvrData.bVerMajor  = PROG_VER_MAJOR;
        SrvrData.bVerMinor  = PROG_VER_MINOR;
        SrvrData.ulInterval = ulInterval;

        /* �ndern der Maskierung */
        SrvrData.dcf77Status.flMaskTO &= !MASK_TO_ALL;

        /* Daten senden */
        dprintS (TXT_BEGINSEND);
        ulErrInterval = 0;

        DosWaitEventSem (hevServer, ulInterval * 1000);
        DosResetEventSem (hevServer, &ulcPost);
        }

    }

#ifdef TRACE
void wrtTrace (PCHAR sz, ...)
    {
    va_list   parg;

    va_start(parg, sz);           /* get pointer to argument list */
    vprintf (sz, parg);
    va_end(parg);                /* done with variable arguments */


    return;
    }

#endif /* TRACE */
