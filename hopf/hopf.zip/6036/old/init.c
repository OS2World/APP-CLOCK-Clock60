#define INCL_DOSFILEMGR
#define INCL_DOSPROCESS
#define STDOUT      1
#define STDIN       0
#define STDERROR    2
#define READONLY_FLAG 0
#include <os2.h>

#pragma check_stack (off)

extern short portaddr;
extern short intervall;
extern short utcflag;
extern short offset;

int get_time (void);

short atoi (char far *a)
{
    short i=0, n=0, v=1;
    while (a[i] == ' ') i++;
    if (a[i] == '-')
    {
        v = -1;
        ++i;
    }
    for (; a[i]>='0'&& a[i]<='9' ; ++i)
        n = 10*n + (a[i]-'0');
    return n*v;
}

char lower (char a)
{
    if (a >= 'A' && a <= 'Z')
        return a + 'a' -'A';
    else
        return a;
}

short hextoint (char far *data)
{
    SHORT i, n=0;
    CHAR  a;

    a = lower (data[0]);
    for (i = 0; (a >= '0' && a <= '9') || (a >= 'a' && a <= 'f'); i++)
    {
        if (a >= 'a' && a <= 'f')
            n = 16*n + (a-'a'+10);
        else
            n = 16*n + (a-'0');
        a = lower (data[i+1]);
    }

    return n;
}

void printtoscreen (char far *data)
{
    USHORT fsize;
    SHORT  size = 0;

    while (data[size] != 0)
        size++;
    if (size > 0)
        DosWrite (STDOUT, data, size, &fsize);

    return;
}

void printchartoscreen (USHORT data)
{
    USHORT fsize, cnt = 0, zws;
    char field[20];
    if (data == 0) {
        DosWrite (STDOUT, "0", 1, &fsize);
        return;
    }
    while (data > 0) {
        zws = data % 10;
        field[cnt] = (char)zws + '0';
        data = data / 10;
        cnt ++;
        field[cnt] = 0;
        if (cnt >18)data = 0;
    }
    DosWrite (STDOUT, field, cnt, &fsize);

    return;
}

short cini ( unsigned char far* strCfg)
{
    SHORT sCnt;
    SHORT sError;

    sCnt=0;
    sError = FALSE;

    while (strCfg[sCnt] != '\0')
    {
        if ((strCfg[sCnt] == '-') || (strCfg[sCnt] == '/'))
        {
            sCnt++;
            switch (strCfg[sCnt])
            {
                case 'P':
                case 'p':
                    do
                    {
                        sCnt++;
                    } while (strCfg[sCnt] == ' ');
                    if ((strCfg[sCnt] == ':') || (strCfg[sCnt] == '='))
                    {
                       do
                       {
                           sCnt++;
                       } while (strCfg[sCnt] == ' ');
                       portaddr = hextoint (&(strCfg[sCnt]));
                    }
                    break;

                case 'I':
                case 'i':
                    do
                    {
                        sCnt++;
                    } while (strCfg[sCnt] == ' ');
                    if ((strCfg[sCnt] == ':') || (strCfg[sCnt] == '='))
                    {
                       do
                       {
                           sCnt++;
                       } while (strCfg[sCnt] == ' ');
                       intervall = atoi (& (strCfg[sCnt]));
                    }
                    break;

                case 'U':
                case 'u':
                    utcflag = 1;
                    break;

                case 'O':
                case 'o':
                    do
                    {
                        sCnt++;
                    } while (strCfg[sCnt] == ' ');
                    if ((strCfg[sCnt] == ':') || (strCfg[sCnt] == '='))
                    {
                       do
                       {
                           sCnt++;
                       } while (strCfg[sCnt] == ' ');
                       offset = atoi (& (strCfg[sCnt]));
                    }
                    break;

                default:
                    sError = TRUE;
                    printtoscreen ("HOPF6036 - Treiber:\r\nUng�ltiger Parameter in Config.sys angegeben\r\n");
                    break;
            }
        }
        sCnt++;
    }
    get_time ();
    return sError;
}

