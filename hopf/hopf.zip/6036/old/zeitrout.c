#pragma check_stack (off)
#include "os2.h"
#include "hopf6036.h"
#include "dcfioctl.h"
//#include "zeit.h"

static USHORT usMaskSt = MASK_ST_ANT       +    // Info �ber Ersatzantenne
                         MASK_ST_HLEAP     +    // Info �ber Stundensprung
                         MASK_ST_SLEAP     +    // Info �ber Schaltsekunde
                         MASK_ST_TZONE1    +    // Info �ber Zeitzone 1
                         MASK_ST_TZONE2    +    // Info �ber Zeitzone 2
                         MASK_ST_CARRIER   +    // Info �ber Tr�ger vorhanden
                         MASK_ST_TIMEVALID +    // Info �ber Zeit g�ltig
                         MASK_ST_SET       ;    // Info �ber Zahl der Setzvorg�nge
static SHORT clocksetcnt = 0;
static DCF77_DATETIME dt;

short utcflag    = 0;
short offset     = 0;
short portaddr   = 0x280;
short intervall  = 10;

/* Externe Methoden und Variable im masm - code */
void outbyte (short port, short value);
UCHAR inbyte (short port);
void INT_3 (void);

USHORT bin2bcd (USHORT us)
{
    return ((us/10)*0x10 + (us%10));
}

USHORT bcd2bin (USHORT us)
{
    return ((us/0x10)*10 + (us%0x10));
}

SHORT last_day (int month, int year)
{
    static SHORT sDays[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    SHORT        rc;

    month--;
    rc = sDays[month];

    /* special handling for february: leap year = 29 days */
    if (month == 1)
    {
        if ((year % 4) == 0)
        {
            if ((year % 100) == 0)
            {
                if ((year % 400) == 0)
                    rc = 29;
            }
            else
                rc = 29;
        }
    }

    return rc;
}

int get_time (void)
{
    int my_offset;
    int stat_val;

    stat_val = inbyte (portaddr + OFFSET_STAT);
    if (((stat_val & HSTAT_DCFTIME) == 0) ||          // no DCF time
        (stat_val == 0xFF))                           // HW not found
       return FALSE;

    dt.hours    = bcd2bin (inbyte (portaddr + OFFSET_HOUR));
    dt.minutes  = bcd2bin (inbyte (portaddr + OFFSET_MIN ));
    dt.seconds  = bcd2bin (inbyte (portaddr + OFFSET_SEC ));
    dt.day      = bcd2bin (inbyte (portaddr + OFFSET_DAY ));
    dt.month    = bcd2bin (inbyte (portaddr + OFFSET_MON ));
    dt.year     = bcd2bin (inbyte (portaddr + OFFSET_YEAR));
    dt.timezone = (SHORT)TZ_DCF;

    my_offset = offset;
    if (utcflag)
    {
        if (stat_val & HSTAT_TZONE1)
            my_offset -= 1;
        if (stat_val & HSTAT_TZONE2)
            my_offset -= 2;
    } /* endif */

    dt.hours += offset;
    dt.year  += (dt.year > 80 ? 1900 : 2000);

    if (dt.hours > 23)
    {
        dt.hours -= 24;
        dt.day++;
        if (dt.day > last_day (dt.month, dt.year))
        {
            dt.day -= last_day (dt.month, dt.year);
            dt.month++;
            if (dt.month > 12)
            {
                dt.month -= 12;
                dt.year++;
            } /* endif month */
        } /* endif day */

    } /* endif hours */

    if (dt.hours < 0)
    {
        dt.hours += 24;
        dt.day--;
        if (dt.day > 1)
        {
            dt.month--;
            dt.day += last_day (dt.month, dt.year);
            if (dt.month < 1)
            {
                dt.month += 12;
                dt.year--;
            } /* endif month */
        } /* endif */
    } /* endif */

    return TRUE;
}

int ioctl_fctn (UCHAR far* newdate, USHORT categUfkt)
{
    USHORT categ = (USHORT)categUfkt /256;
    USHORT fkt   = (USHORT)categUfkt %256;
    UCHAR  ucVal;
    SHORT  i;
    SHORT  port;

    if (categ == IOCTL_DCF77)
    {
        if (fkt == DCF77_GETSTATUS)
        {
            // Neue FKT
            DCF77_STATUS far *status = (DCF77_STATUS far *)newdate;
            if (TestSeg (newdate, sizeof (DCF77_STATUS)) == 1)
                return 0x8103;

            status->cDrvType        = DRVTYPE_HOPF6036;   // Treiber ist ZEIT.SYS
            status->cVerMajor       = H_VERSION;          // Hauptversionsnummer
            status->cVerMinor       = SW_VERSION;         // Unterversionsnummer
            status->bIsHRTimerAvail = FALSE;            // HR-Timer nicht verf�gbar
            status->bPolarity       = 0;                  // Polarit�t 0=negativ, 1=positiv
            status->uscBadSeconds   = 0;                  // empfangene falsche Zeiten
            status->uscGoodSeconds  = 0;                  // empfangene korrekte Zeiten
            status->uscTimeSet      = clocksetcnt;        // Zahl der Setzvorg�nge
            status->flStatus        = 0;
            status->flMaskST        = usMaskSt;
            status->flMaskSS        = MASK_SS_HOPF;
            status->flMaskTO        = MASK_TO_ALL;
            status->flMaskIV        = MASK_IV_UPDATE;
            status->flMaskLN        = 0;

            ucVal = inbyte (portaddr + OFFSET_STAT);
            if (ucVal != 0xFF)
            {
                if (ucVal & HSTAT_ANT)
                    status->flStatus |= STATUS_ANT;
                if (ucVal & HSTAT_HLEAP)
                    status->flStatus |= STATUS_HLEAP;
                if (ucVal & HSTAT_SLEAP)
                    status->flStatus |= STATUS_SLEAP;
                if (ucVal & HSTAT_TZONE1)
                    status->flStatus |= STATUS_TZONE1;
                if (ucVal & HSTAT_TZONE2)
                    status->flStatus |= STATUS_TZONE2;
                if (ucVal & HSTAT_DCFTIME)
                    status->flStatus |= STATUS_TIMEVALID + STATUS_CARRIER;
            } /* endif */

            return 0;
        } // Ende Getstatus

        if (fkt == DCF77_GETDATETIME)
        {
            DCF77_DATETIME far *datetime = (DCF77_DATETIME far *)newdate;
            if (TestSeg (newdate, sizeof (DCF77_DATETIME)) == 1)
                return 0x8103;

            if (get_time ())
            {
              datetime->hours    = dt.hours;
              datetime->minutes  = dt.minutes;
              datetime->seconds  = dt.seconds;
              datetime->day      = dt.day;
              datetime->month    = dt.month;
              datetime->year     = dt.year;
              datetime->timezone = dt.timezone;
            }
            return 0;
        } // Ende GetDate

        if (fkt == DCF77_QUERYOFFSET)
        {
            DCF77_OFFSET far *offs = (DCF77_OFFSET far *)newdate;
            if (TestSeg (newdate, sizeof (DCF77_OFFSET)) == 1)
                return 0x8103;

            offs->flUTC =   utcflag;
            offs->sOffset = offset;  // Zeitoffset -3...+2 Stunden
            return 0;
        }

        if (fkt == DCF77_QUERYDATA)
        {
            DCF77_DATA far *data = (DCF77_DATA far *)newdate;
            if (TestSeg (newdate, sizeof (DCF77_DATA)) == 1)
                return 0x8103;

            data->bSupply       = 0;
            data->bcRepeat      = 0;
            data->usIOAddr      = (USHORT)portaddr;
            data->usSetInterval = (USHORT)intervall;
            data->usThreshold   = 0;
            data->bPort         = PORT_HOPF6036;
            return 0;
        }

        if (fkt == DCF77_SETOFFSET)
        {
            DCF77_OFFSET far *offs = (DCF77_OFFSET far *)newdate;
            if (TestSeg (newdate, sizeof (DCF77_OFFSET)) == 1)
                return 0x8103;

            utcflag = offs->flUTC;
            if ((offs->sOffset > -3 ) && (offs->sOffset < 4))
                offset = (char)offs->sOffset;
            else
                return 0x8103;
            return 0;
        }

        if (fkt == DCF77_SETDATA)
        {
            DCF77_DATA far *data = (DCF77_DATA far *)newdate;
            if (TestSeg (newdate, sizeof (DCF77_DATA)) == 1)
                return 0x8103;

            portaddr = data->usIOAddr;
            if (data->usSetInterval > 0)
                intervall   = (short) data->usSetInterval;
            return 0;
        }

        if (fkt == DCF77_SETPORT)
        {
            DCF77_PORT far *data = (DCF77_PORT far *)newdate;
            if (TestSeg (newdate, sizeof (DCF77_PORT)) == 1)
                return 0x8103;

            for (i=0; i<data->bNum; i++)
            {
               port = portaddr + data->ppData[i].bPortOfs;
               outbyte (port, data->ppData[i].bValue);
            } /* endfor */
            return 0;
        }

        if (fkt == DCF77_GETMILLI)
        {
            DCF77_MILLI far *data = (DCF77_MILLI far *)newdate;
            if (TestSeg (newdate, sizeof (DCF77_MILLI)) == 1)
                return 0x8103;

                if ((inbyte (portaddr+0x3B) == 0x58) && (inbyte (portaddr+0x3C) == 0x4E))
                    data->usValue = inbyte (portaddr+0x38) + (inbyte (portaddr+0x39) * 256);
                else
                    data->usValue = 0xFFFF;
            return 0;
        }
    }
}

int set_clock (void)
{
    short validflag=0;
    int writeok;

    for (writeok=0; writeok <10; writeok++)
    {
        /* versuche bis zu 10 mal Datum zu setzten */
        outbyte (0x70, 10);
        validflag=inbyte (0x71);
        if ((validflag & 0x80) == 0)
        {
           outbyte (0x70, 11);
           validflag=inbyte (0x71);
           outbyte (0x70, 11);
           outbyte (0x71, validflag | 0x80);
           outbyte (0x70, 0);
           outbyte (0x71, bin2bcd (dt.seconds));
           outbyte (0x70, 2);
           outbyte (0x71, bin2bcd (dt.minutes));
           outbyte (0x70, 4);
           outbyte (0x71, bin2bcd (dt.hours));
           outbyte (0x70, 7);
           outbyte (0x71, bin2bcd (dt.day));
           outbyte (0x70, 8);
           outbyte (0x71, bin2bcd (dt.month));
           outbyte (0x70, 9);
           outbyte (0x71, bin2bcd (dt.year % 100));
           outbyte (0x70, 11);
           outbyte (0x71, validflag & 0x7F);
           return TRUE;
       }
    }
    return FALSE;
}

void timer_fctn (void)
{
    static short intervallcnt = 2;

    intervallcnt--;

    if (intervallcnt <= 0)
    {
        if ((get_time ()) && (set_clock ()))    // wait time is successfull
        {
            intervallcnt = intervall;
            clocksetcnt++;
        }
    } /* endif */
}

