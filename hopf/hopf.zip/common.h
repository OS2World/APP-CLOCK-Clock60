/***************************************************************************\
 *
 * PROGRAMMNAME: HOPF603x
 * -------------
 *
 * VERSION: 4.4
 * --------
 *
 * MODULNAME: COMMON
 * ----------
 *
 * BESCHREIBUNG: gemeinsame Funktionen f�r 6036 und 6038-Treiber
 * -------------
 *
 * HINWEISE:
 * ---------
 *
 *  Ver.    Date      Comment
 *  ----    --------  -------
 *  4.40    06-21-00  Erste Version
 *
 *  Copyright (C) noller & breining software 1995...2000
 *
\******************************************************************************/
#ifndef COMMON_H
#define COMMON_H

#include "dcfioctl.h"

short atoi (char far *a);
char lower (char a);
short hextoint (char far *data);
USHORT bin2bcd (USHORT us);
USHORT bcd2bin (USHORT us);
void printtoscreen (char far *data);
void printchartoscreen (USHORT data);
SHORT LastDay (int month, int year);
int setClock (DCF77_DATETIME *pdt);

#endif /* COMMON_H */
